// ── Dark mode toggle ─────────────────────────────────────────────────────
(function () {
  const toggle = document.querySelector('[data-theme-toggle]');
  const root = document.documentElement;
  let theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  root.setAttribute('data-theme', theme);
  updateToggleIcon();

  function updateToggleIcon() {
    if (!toggle) return;
    toggle.innerHTML = theme === 'dark'
      ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
      : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    toggle.setAttribute('aria-label', `Chuyển sang chế độ ${theme === 'dark' ? 'sáng' : 'tối'}`);
  }

  toggle && toggle.addEventListener('click', () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', theme);
    updateToggleIcon();
  });
})();

// ── Navbar hamburger ─────────────────────────────────────────────────────
const hamburger = document.querySelector('.nav-hamburger');
const navLinks = document.querySelector('.nav-links');
const navActions = document.querySelector('.nav-actions');

hamburger && hamburger.addEventListener('click', () => {
  const isOpen = hamburger.getAttribute('aria-expanded') === 'true';
  hamburger.setAttribute('aria-expanded', !isOpen);

  if (!isOpen) {
    navLinks && navLinks.classList.add('nav-open');
    navActions && navActions.classList.add('nav-open');
    hamburger.style.cssText = '';
  } else {
    navLinks && navLinks.classList.remove('nav-open');
    navActions && navActions.classList.remove('nav-open');
  }
});

// Mobile nav styles injected via JS
const mobileStyle = document.createElement('style');
mobileStyle.textContent = `
  @media (max-width: 768px) {
    .nav-links.nav-open, .nav-actions.nav-open {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 64px;
      left: 0; right: 0;
      background: var(--color-bg);
      border-bottom: 1px solid var(--color-border);
      padding: 1rem 1.5rem;
      gap: 0.5rem;
      z-index: 99;
      backdrop-filter: blur(16px);
      animation: slideDown 0.2s ease;
    }
    .nav-actions.nav-open {
      top: auto;
      top: calc(64px + var(--mobile-nav-height, 280px));
      flex-direction: row;
      flex-wrap: wrap;
      border-top: none;
    }
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  }
`;
document.head.appendChild(mobileStyle);

// ── Scroll-triggered fade-in ─────────────────────────────────────────────
const observerStyle = document.createElement('style');
observerStyle.textContent = `
  .fade-in-up {
    opacity: 0;
    transform: translateY(24px);
    transition: opacity 0.6s ease, transform 0.6s ease;
  }
  .fade-in-up.visible {
    opacity: 1;
    transform: translateY(0);
  }
`;
document.head.appendChild(observerStyle);

// Add fade-in-up to sections
document.querySelectorAll('.feature-item, .topic-card, .step-card').forEach((el, i) => {
  el.classList.add('fade-in-up');
  el.style.transitionDelay = `${i * 60}ms`;
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.fade-in-up').forEach(el => observer.observe(el));

// ── Navbar scroll shadow ──────────────────────────────────────────────────
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 10) {
    navbar.style.boxShadow = '0 4px 24px rgba(147,51,234,0.1)';
  } else {
    navbar.style.boxShadow = 'none';
  }
}, { passive: true });
